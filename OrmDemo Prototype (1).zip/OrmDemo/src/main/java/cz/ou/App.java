package cz.ou;

import cz.ou.db.Faculty;
import cz.ou.db.University;
import cz.ou.db.UniversityRepository;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        createUniversity();
        createFaculty();
    }

    private static void createFaculty() {
        UniversityRepository universityRepository =
                new UniversityRepository();
        University university =
                universityRepository.getById(1);

        Faculty faculty = new Faculty();
        faculty.setTitle("Přírodovědecká fakulta");
        faculty.setUniversity(university);

        FacultyRepository facultyRepository =
                new FacultyRepository();
        facultyRepository.save(faculty);
    }

    private static void createUniversity() {
        University university = new University();
        university.setTitle("Ostravská univerzita");

        UniversityRepository universityRepository =
                new UniversityRepository();

        universityRepository.save(university);
    }
}
