package cz.ou.db;

import javax.persistence.*;

@Entity
public class Faculty {
  private int facultyId;
  private String title;
  private University university;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Faculty faculty = (Faculty) o;

    if (facultyId != faculty.facultyId) return false;
    if (title != null ? !title.equals(faculty.title) : faculty.title != null) return false;

    return true;
  }

  @Id
  @Column(name = "FACULTY_ID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public int getFacultyId() {
    return facultyId;
  }

  public void setFacultyId(int facultyId) {
    this.facultyId = facultyId;
  }

  @Basic
  @Column(name = "TITLE")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  @ManyToOne
  @JoinColumn(name = "UNIVERSITY_ID", referencedColumnName = "UNIVERSITY_ID", nullable = false)
  public University getUniversity() {
    return university;
  }

  public void setUniversity(University university) {
    this.university = university;
  }

  @Override
  public int hashCode() {
    int result = facultyId;
    result = 31 * result + (title != null ? title.hashCode() : 0);
    return result;
  }
}
