package cz.ou.db;

import javax.persistence.*;
import java.util.Collection;

@Entity
public class University {
  private int universityId;
  private String title;
  private Collection<Faculty> facultiesByUniversityId;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    University that = (University) o;

    if (universityId != that.universityId) return false;
    if (title != null ? !title.equals(that.title) : that.title != null) return false;

    return true;
  }

  @OneToMany(mappedBy = "university")
  public Collection<Faculty> getFacultiesByUniversityId() {
    return facultiesByUniversityId;
  }

  public void setFacultiesByUniversityId(Collection<Faculty> facultiesByUniversityId) {
    this.facultiesByUniversityId = facultiesByUniversityId;
  }

  @Basic
  @Column(name = "TITLE")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  @Id
  @Column(name = "UNIVERSITY_ID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public int getUniversityId() {
    return universityId;
  }

  public void setUniversityId(int universityId) {
    this.universityId = universityId;
  }

  @Override
  public int hashCode() {
    int result = universityId;
    result = 31 * result + (title != null ? title.hashCode() : 0);
    return result;
  }
}
