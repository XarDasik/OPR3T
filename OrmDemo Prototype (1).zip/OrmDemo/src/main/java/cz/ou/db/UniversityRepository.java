package cz.ou.db;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class UniversityRepository {
  private static final String PU_NAME = "UniversityDB";
  private static EntityManagerFactory emf = null;
  private static EntityManager em = null;

  private void init() {
    try {
      if (emf == null)
        emf = javax.persistence.Persistence
                .createEntityManagerFactory(PU_NAME);
      if (em == null)
        em = emf.createEntityManager();
    } catch (Exception e) {
      throw new DbException(
              "Failed to create emf or em.", e);
    }
  }

  public void save(University university){
    init();

    try {
      em.getTransaction().begin();
      em.persist(university);
      em.getTransaction().commit();
    } catch (Exception e) {
      throw new DbException(
              "Failed to save university.", e);
    }
  }
}
