package cz.ou;

import cz.ou.db.Car;
import cz.ou.db.CarRepository;
import cz.ou.db.Employee;
import cz.ou.db.EmployeeRepository;

import java.util.List;

public class App 
{
    public static void main( String[] args ){
        createCars();
        createEmployees();
        printAll();
    }
    private static void printAll() {
        List<Car> cars = new CarRepository().findAll();

        for (Car car : cars) {
            System.out.printf("%d.\t%s%n",
                    car.getCarId(),
                    car.getModel());
            for (Employee employee : car.getEmployees()) {
                System.out.printf("\t%d.\t%s%n",
                        employee.getEmployeeId(),
                        employee.getName());
            }
        }
    }
    private static void createEmployees() {
        CarRepository carRepository =
                new CarRepository();
        Car car = carRepository.find(1);

        EmployeeRepository employeeRepository =
                new EmployeeRepository();

        Employee employee = new Employee();
        employee.setName("Jan Rubeš");
        employee.setCarByCarId(car);
        employeeRepository.save(employee);

        employee.setName("Karel Richter");
        employee.setCarByCarId(car);
        employeeRepository.save(employee);

        car = carRepository.find(2);
        employee.setName("Světlana Vrasovičová");
        employee.setCarByCarId(car);
        employeeRepository.save(employee);
    }

    private static void createCars() {
        CarRepository carRepository =
                new CarRepository();

        Car car = new Car();
        car.setModel("Škoda Octavia");
        carRepository.save(car);

        car.setModel("Škoda Superb");
        carRepository.save(car);
    }
}
