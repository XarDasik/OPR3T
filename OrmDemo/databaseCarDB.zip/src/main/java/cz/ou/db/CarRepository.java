package cz.ou.db;

public class CarRepository extends Repository<Car> {
    public CarRepository() {super(Car.class);}
}
