package cz.ou.db;

public class EmployeeRepository extends Repository<Employee> {
    public EmployeeRepository() {
        super(Employee.class);
    }
}
