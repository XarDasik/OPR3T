package cz.ou.db;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import java.util.List;

public abstract class Repository<T> {
  private static final String PU_NAME = "CarDB";
  private static EntityManagerFactory emf = null;
  private static EntityManager em = null;
  private final Class<T> entityType;

  private void init() {
    try {
      if (emf == null)
        emf = javax.persistence.Persistence
                .createEntityManagerFactory(PU_NAME);
      if (em == null)
        em = emf.createEntityManager();
    } catch (Exception e) {
      throw new DbException(
              "Failed to create emf or em.", e);
    }
  }


  public Repository(Class<T> type) {
    this.entityType = type;
  }

  public void save(T entity) {
    init();

    try {
      em.getTransaction().begin();
      em.persist(entity);
      em.getTransaction().commit();
    } catch (Exception e) {
      throw new DbException(
              "Failed to save " + this.entityType.getName(), e);
    }
  }

  public T find(int id) {
    init();

    T ret;

    try {
      ret = em.find(this.entityType, id);
    } catch (Exception e) {
      throw new DbException(
              "Failed to get " + this.entityType.getName() + " by id.",
              e);
    }

    return ret;
  }

  public void delete(int id) {
    init();

    try {
      em.getTransaction().begin();
      T entity = em.getReference(this.entityType, id);
      em.remove(entity);
      em.getTransaction().commit();
    } catch (Exception e) {
      throw new DbException("Failed to delete " + this.entityType.getName(), e);
    }
  }

  public List<T> findAll() {
    init();


    TypedQuery<T> query;
    try {
      query = em.createNamedQuery("findAll", entityType);
    } catch (Exception e) {
      throw new DbException("Unable to find 'findAll' named query " +
              "for type " + entityType.getName(),
              e);
    }

    List<T> ret;

    try {
      ret = query.getResultList();
    } catch (Exception e) {
      throw new DbException(
              "Failed to list of " + this.entityType.getName(),
              e);
    }

    return ret;
  }
}
